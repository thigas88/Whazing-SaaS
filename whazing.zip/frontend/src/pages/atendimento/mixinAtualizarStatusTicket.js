import { AtualizarStatusTicket } from 'src/service/tickets'
const userId = +localStorage.getItem('userId')

export default {
  methods: {
    async iniciarAtendimento(ticket) {
      this.loading = true
      const contactName = (ticket.contact && ticket.contact.name) || (this.contatoSelecionado ? this.contatoSelecionado.name : 'Cliente')
      try {
        await AtualizarStatusTicket(ticket.id, 'open', userId)
        this.loading = false
        this.$q.notify({
          message: `Atendimento Iniciado || ${contactName} - Ticket: ${ticket.id}`,
          type: 'positive',
          progress: true,
          position: 'top',
          actions: [{
            icon: 'close',
            round: true,
            color: 'white'
          }]
        })
        this.$store.commit('TICKET_FOCADO', {})
        this.$store.commit('SET_HAS_MORE', false)
        this.$store.dispatch('AbrirChatMensagens', ticket)
      } catch (error) {
        this.loading = false
        console.error(error)
        this.$notificarErro('Não foi possível atualizar o status', error)
      }
    },
    atualizarStatusTicket2 (ticket) {
      const contatoName = ticket.contact.name || ''
      const ticketId = ticket.id
      const userId = this.$store.state.user.id // Pegar o userId da store

      const title = 'Encerrar o atendimento?'
      const toast = 'Atendimento encerrado!'

      this.$q.dialog({
        title: title,
        message: `Cliente: ${contatoName} || Ticket: ${ticketId}`,
        cancel: {
          label: 'Não',
          color: 'negative',
          push: true
        },
        ok: {
          label: 'Sim',
          color: 'primary',
          push: true
        },
        persistent: true
      }).onOk(() => {
        this.loading = true
        AtualizarStatusTicket(ticketId, 'closed', userId)
          .then(res => {
            this.loading = false
            this.$q.notify({
              message: `${toast} || ${contatoName} (Ticket ${ticketId})`,
              type: 'positive',
              progress: true,
              actions: [{
                icon: 'close',
                round: true,
                color: 'white'
              }]
            })
            this.$store.commit('TICKET_FOCADO', {})
            this.$router.push({ name: 'chat-empty' }) // Redireciona para a página 'chat-empty'
          })
          .catch(error => {
            this.loading = false
            this.$q.notify({
              message: 'Atendimento nessa conexão já iniciado ou solicite ao admin para abrir um novo atendimento na opção contato.',
              type: 'warning',
              progress: true,
              actions: [{
                icon: 'close',
                round: true,
                color: 'white'
              }]
            })
            console.error(error)
            this.$notificarErro('Não foi possível encerrar o atendimento', error)
          })
      })
    },
    atualizarStatusTicket (status) {
      const contatoName = this.ticketFocado.contact.name || ''
      const ticketId = this.ticketFocado.id
      const title = {
        open: 'Atendimento será iniciado, ok?',
        pending: 'Retornar à fila?',
        closed: 'Encerrar o atendimento?'
      }
      const toast = {
        open: 'Atendimento iniciado!',
        pending: 'Retornado à fila!',
        closed: 'Atendimento encerrado!'
      }

      this.$q.dialog({
        title: title[status],
        message: `Cliente: ${contatoName} || Ticket: ${ticketId}`,
        cancel: {
          label: 'Não',
          color: 'negative',
          push: true
        },
        ok: {
          label: 'Sim',
          color: 'primary',
          push: true
        },
        persistent: true
      }).onOk(() => {
        this.loading = true
        AtualizarStatusTicket(ticketId, status, userId)
          .then(res => {
            this.loading = false
            this.$q.notify({
              message: `${toast[status]} || ${contatoName} (Ticket ${ticketId})`,
              type: 'positive',
              progress: true,
              actions: [{
                icon: 'close',
                round: true,
                color: 'white'
              }]
            })
            this.$store.commit('TICKET_FOCADO', {})
            if (status !== 'open') this.$router.push({ name: 'chat-empty' })
          })
          .catch(error => {
            this.loading = false
            this.$q.notify({
              message: 'Atendimento nessa conexão já iniciado na aba aberto/pendente ou solicite ao admin para abrir um novo atendimento na opção contato.',
              type: 'warning',
              progress: true,
              actions: [{
                icon: 'close',
                round: true,
                color: 'white'
              }]
            })
            console.error(error)
            this.$notificarErro('Não foi possível atualizar o status', error)
          })
      })
    }
  }
}
